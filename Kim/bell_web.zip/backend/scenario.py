"""시나리오 RAG (잠긴 종) — 검색 부분만. 노트북 sce_rag_v4의 ##1~##6을 .py로 옮긴 것.

  카드 읽기(##1~2) → can_search 필터(##3) → 청크(##4) → 임베딩(##5) → search(##6)

  + 서술 생성(노트북 ##10~##11): 찾은 카드만 근거로 Ollama 모델이 장면을 쓴다.

밖에서 쓰는 함수
  load()                          서버를 켤 때 한 번. 카드를 읽고 임베딩 모델을 올린다.
  find_cards(question, state, k)  질문 + 지금 상태 → 볼 수 있는 카드 중 비슷한 k장 (dict 목록)
  narrate_scene(text, state, history)  검색 + 서술 + 규칙 검사. (서술, 카드, 검사 결과)
  configure(ollama_url, model)    서술에 쓸 Ollama 주소와 모델 이름

state 모양: {"scene": 3, "flags": set, "visited": set, "cls": "fighter"}
  엔진 상태에서 만들려면 state_from_engine(engine)을 쓴다.

노트북과 다른 점: Chroma 대신 numpy로 코사인 유사도를 직접 계산한다 (벡터가 정규화돼 있어
내적 = 코사인 유사도라 순위·점수가 같다). 카드가 112장뿐이라 이쪽이 더 단순하다.
"""
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
CARDS_PATH = ROOT / "game" / "data" / "cards.json"
EMBED_MODEL = "intfloat/multilingual-e5-small"

ROOM_ONLY = True   # True: 지금 서 있는 방(state["room"])의 카드와 방 없는 카드(엔딩)만 검색한다. False: 가 본 방 전체

_ready = False
_cards = {}        # id -> 카드 원본
_rooms = {}        # 방 id -> 한글 이름
_ids = []          # 검색 대상 카드 id (player_text가 있는 카드)
_vectors = None    # (카드 수, 384) 정규화된 벡터
_model = None


# ---------------------------------------------------------------- ##3 필터
def can_search(card, state):
    """지금 이 플레이어에게 보여도 되는 카드인가? (엔진 Engine.eligible과 같은 규칙)"""
    if state["scene"] < card["reveal_after"]:
        return False        # 아직 공개 장면이 아님
    if card["req_flag"] and card["req_flag"] not in state["flags"]:
        return False        # 필요한 플래그가 없음
    if card["room"] and card["room"] not in state["visited"]:
        return False        # 아직 가 보지 않은 방
    if card["owner"] != "all" and card["owner"] != state["cls"]:
        return False        # 다른 직업 전용 카드
    return True


# ---------------------------------------------------------------- ##4 청크
def make_chunk_text(card):
    """"[종류] 방이름" 머리말 + player_text (GM 문장은 넣지 않는다)."""
    header = f"[{card['label']}]"
    room_name = _rooms.get(card["room"], "")
    if room_name:
        header += f" {room_name}"
    return header + "\n" + card["player_text"]


# ---------------------------------------------------------------- ##1~2, ##5 준비
def load():
    """카드를 읽고 임베딩 모델을 올려 카드 전체를 벡터로 만든다. 처음 한 번만 실행된다."""
    global _ready, _model, _vectors
    if _ready:
        return
    from sentence_transformers import SentenceTransformer   # 무거워서 필요할 때만 불러온다

    data = json.loads(CARDS_PATH.read_text(encoding="utf-8"))
    _rooms.update(data["rooms"])
    for c in data["cards"]:
        _cards[c["id"]] = c
        if c["player_text"]:                                # GM 전용 카드(player_text 없음)는 검색 대상 아님
            _ids.append(c["id"])
    _model = SentenceTransformer(EMBED_MODEL)
    texts = ["passage: " + make_chunk_text(_cards[i]) for i in _ids]
    _vectors = _model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
    _ready = True


# ---------------------------------------------------------------- ##6 검색
def search(question, state, k=3, use_filter=True):
    """질문과 비슷한 순으로 카드를 훑으면서, 지금 볼 수 있는 카드만 남겨 앞에서 k개. [(카드 id, 유사도)]"""
    load()
    q = _model.encode("query: " + question, normalize_embeddings=True)
    sims = _vectors @ q                                     # 모든 카드와의 코사인 유사도
    room_now = state.get("room")                            # 지금 서 있는 방 (없으면 None -> 방 제한을 걸지 않음)
    hits = []
    for i in np.argsort(-sims):
        cid = _ids[i]
        if use_filter and not can_search(_cards[cid], state):
            continue
        if use_filter and ROOM_ONLY and room_now and _cards[cid]["room"] and _cards[cid]["room"] != room_now:
            continue                                        # 다른 방의 카드는 건너뜀 (방이 없는 엔딩 카드는 통과)
        hits.append((cid, round(float(sims[i]), 3)))
        if len(hits) == k:
            break
    return hits


def find_cards(question, state, k=3):
    """search 결과를 화면·다른 파트가 쓰기 좋게 dict 목록으로 바꾼다."""
    return card_dicts(search(question, state, k))


# ================================================================ 서술 생성 (노트북 ##10~##11)
# 검색한 카드의 player_text만 모델에게 주고, 모델이 장면을 서술한다. 규칙을 어긴 서술은 다시 쓰게 한다.
import re
import time

import requests

OLLAMA_URL = "http://localhost:11434"
GEN_MODEL = "qwen2.5:14b"
NUM_CTX = 8192


def configure(ollama_url=None, model=None):
    """서버를 켤 때 Ollama 주소와 모델 이름을 바꾼다 (안 부르면 위 기본값)."""
    global OLLAMA_URL, GEN_MODEL
    OLLAMA_URL = (ollama_url or OLLAMA_URL).rstrip("/")
    GEN_MODEL = model or GEN_MODEL


def ask_llm(messages, max_new_tokens=300, seed=42, temperature=0.0):
    res = requests.post(f"{OLLAMA_URL}/api/chat", timeout=600, json={
        "model": GEN_MODEL, "messages": messages, "stream": False,
        "options": {"temperature": temperature,      # 0 = 같은 입력 -> 같은 출력 (재시도할 때는 올린다)
                    "seed": seed, "num_ctx": NUM_CTX, "num_predict": max_new_tokens}})
    res.raise_for_status()
    return res.json()["message"]["content"].strip()


GM_SYSTEM = ("You are the game master of a Korean single-player D&D adventure. Write every reply in natural Korean (Hangul). "
             "Never use Chinese characters, Japanese, or any other language.")

GM_TEMPLATE = """당신은 1인용 TRPG의 게임 마스터입니다. 아래 규칙을 지키세요.
1. [참고 자료]에 있는 내용만 사용해 지금 장면을 묘사하세요. 자료에 없는 인물, 장소, 사건, 물건을 지어내지 마세요.
2. 플레이어를 '당신'이라고 부르세요. 당신의 행동, 생각, 감정, 대사를 대신 정하지 마세요.
3. 행동은 시도하는 모습과 눈에 보이는 반응까지만 쓰세요. 물건을 받거나 얻는 것, 길이 열리는 것, 누가 쓰러지거나 동의하는 것 같은 결과는 쓰지 마세요. 결과는 게임이 따로 정합니다.
4. 입력에 답할 수 있는 내용이 [참고 자료]에 없으면, 지금은 새로 알 수 있는 것이 없다고 짧게 쓰세요.
5. NPC는 참고 자료에 적힌 성격대로 짧게 말하게 하되, 자료에 없는 사실을 말하게 하지 마세요.
6. 플레이어가 지난 일을 물으면 [최근 기록]에 있는 내용으로 짧게 알려 주세요. 거기 없으면 기억나지 않는다고 하세요.
7. 2~4문장으로 쓰세요. HP, DC 같은 게임 수치와 출처는 쓰지 마세요. 마지막에 "어떻게 하시겠어요?" 같은 질문은 쓰지 마세요.
8. [장소]에 없는 인물이나 장소는 등장시키지 마세요. 지금 이 방에서 보이는 것만 쓰세요.

[장소] {room}

[참고 자료]
{docs}

[최근 기록]
{history}

[플레이어] {action}
[GM]"""

# 서술을 검사하는 규칙 (걸리면 문제를 알려 주고 다시 쓰게 한다)
BROKEN = re.compile(r"[^가-힣ㄱ-ㆎ\x00-\x7f\s…·“”‘’—–]")        # 한글·영문·기호 말고 다른 글자 (한자 등)
LEAK = re.compile(r"\b(HP|DC|CR|SRD)\b|p\.\s*\d+|scn-")                          # 게임 수치·출처 노출
OUTCOME = re.compile(r"(건네|건넨|넘겨|내어\s*준|내준|받았|받는다|획득|쥐여|꺼내\s*준|얻었|얻는다|열렸|쓰러졌|쓰러진다)")   # 결과를 확정하는 말
NO_NEWS = "지금은 이 행동을 할 수 없을 거 같다. 다른 행동을 해 보자."


def narration_problems(body):
    p = []
    if BROKEN.search(body): p.append("깨진 글자")
    if LEAK.search(body): p.append("게임 수치·출처 노출")
    if len(body) < 20: p.append("너무 짧음")
    if re.search(r"플레이어|주인공", body): p.append("호칭")
    if OUTCOME.search(body): p.append("행동의 결과를 확정함")
    return p


def clean_body(body):
    # 끝까지 문제가 남았을 때: 문제 있는 문장을 빼고, 남는 게 없으면 한 줄 안내
    body = re.sub(r"플레이어|주인공", "당신", body)
    sents = re.split(r"(?<=[.!?…])\s+|\n+", body)
    kept = " ".join(s for s in sents if s and not (BROKEN.search(s) or LEAK.search(s) or OUTCOME.search(s))).strip()
    return kept if len(kept) >= 20 else NO_NEWS


def recent_records(history, n=6):
    return "\n".join(f"플레이어: {a} / GM: {b}" for a, b in history[-n:]) or "(없음)"


def narrate_scene(text, state, history, k=2, tries=3):
    """자유 입력 한 줄 → (서술, 가져온 카드 [(id, 유사도)], {"tries", "problems"})."""
    load()
    hits = search(text, state, k=k)                                    # 상태 필터가 적용된 시나리오 검색
    if not hits:                                                       # 볼 수 있는 카드가 없으면 모델을 부르지 않는다
        return NO_NEWS, hits, {"tries": 0, "problems": []}
    docs = [_cards[cid]["player_text"] for cid, _ in hits]             # 플레이어용 글만 모델에게 준다
    room_id = state.get("room")                                        # 지금 서 있는 방
    if room_id:
        room = _rooms.get(room_id, room_id)                            # 실제 현재 방의 이름 (검색된 카드 기준이 아님)
    else:                                                              # 방을 모르면 가장 위 카드의 방
        rooms_here = [_rooms.get(_cards[cid]["room"], "") for cid, _ in hits]
        room = next((r for r in rooms_here if r), "(알 수 없음)")
    prompt = GM_TEMPLATE.format(room=room, docs="\n\n".join(f"- {d}" for d in docs) or "(없음)",
                                history=recent_records(history), action=text)
    messages = [{"role": "system", "content": GM_SYSTEM}, {"role": "user", "content": prompt}]
    body, probs = "", []
    llm_started = time.time()                                          # 서술이 느릴 때 모델 시간이 얼마인지 보려고 잰다
    for t in range(tries):
        body = ask_llm(messages, max_new_tokens=250, seed=42 + t, temperature=0.7 if t else 0.3)
        probs = narration_problems(body)
        if not probs:
            break
        messages = messages[:2] + [{"role": "assistant", "content": body},
                                   {"role": "user", "content": "다음 문제가 있어. 고쳐서 다시 써 줘: " + "; ".join(probs)}]
    if probs:
        body = clean_body(body)
    body = re.split(r"\s*(?:(?:어떻게|무엇을|뭘)\s*(?:계속|대응)?\s*하시겠|\[게임 진행)", body)[0].rstrip()   # 끝의 되묻기와 군더더기 제거
    return body, hits, {"tries": t + 1, "problems": probs, "llm_seconds": round(time.time() - llm_started, 1)}


def card_dicts(hits):
    """[(id, 유사도)] → 화면이 보여 줄 dict 목록."""
    out = []
    for cid, sim in hits:
        c = _cards[cid]
        out.append({"id": cid, "label": c["label"], "kind": c["kind"],
                    "room": _rooms.get(c["room"], ""), "text": c["player_text"], "sim": sim})
    return out


def state_from_engine(engine):
    """게임 엔진의 지금 상태 → 검색 필터용 state."""
    s = engine.s
    return {"scene": s.scene, "flags": set(s.flags), "visited": set(s.visited), "cls": engine.hero.cls,
            "room": s.room}                                  # 지금 서 있는 방 (엔진의 현재 위치)
