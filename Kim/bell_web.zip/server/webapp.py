"""브라우저 게임 화면용 로컬 서버 (표준 라이브러리만 사용).

  python -m server.webapp                 # http://127.0.0.1:8000
  python -m server.webapp --port 8765
  python -m server.webapp --narrator ollama --model qwen2.5:7b

역할 분리:
  - game/      : 규칙·판정·주사위·피해·상태 (기존 W1~W6 엔진, 수정 없이 재사용)
  - server/    : 엔진을 HTTP JSON으로 감싼다. 판정이나 계산을 하지 않는다.
                 화면용 정리(누가 말했는지, 상태 이름 한국어 등)만 한다.
  - web/       : 화면 (HTML·CSS·JS). 서버가 준 상태와 결과를 보여 주기만 한다.

API (모두 JSON, web/app.js의 api()가 부른다):
  GET  /api/meta          캐릭터 4명·조우 목록·장면 제목 (메뉴·캐릭터 선택·전투 시험장 화면용)
  GET  /api/state?sid=    현재 상태만 다시 받기
  POST /api/new           {"char", "seed"?, "combat"?, "potions"?} → 새 Engine을 만들고 세션 id(sid) 발급
  POST /api/choose        {"sid", "id"} → Engine.choose(id)
  POST /api/restart       {"sid"} → Engine.restart_from_checkpoint()
  POST /api/free          {"sid", "text"} → [임시] 자유 문장을 현재 선택지 하나에 연결해 choose
                          + 시나리오 RAG 카드(free.cards)와 서술 요청표(free.rag_id)
  POST /api/rag_narrate   {"sid", "rag_id"} → 시나리오 RAG 서술 (느림. 화면이 따로 불러서 선택지를 막지 않음)
  그 밖의 GET 경로는 web/ 폴더의 정적 파일 (index.html, app.js, assets/…)
응답 형식 (/api/new·choose·restart·free·state): Game.reply() → {"sid", "mode", "events", "narration", "state"}
세션은 메모리(Game.sessions)에만 있어서 서버를 끄면 사라진다 (저장 기능 없음).
"""
import argparse
import json
import re
import secrets
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from game.content import Content  # noqa: E402
from game.engine import SKILL_KO, Engine, fmt_money  # noqa: E402
from game.model import ABILITIES, ABILITY_KO  # noqa: E402
from game.narrator import OllamaNarrator, TemplateNarrator  # noqa: E402
from backend import scenario  # noqa: E402  (시나리오 RAG: 자유 입력에 맞는 카드 검색)

WEB = ROOT / "web"
MIME = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8",
        ".svg": "image/svg+xml", ".png": "image/png", ".json": "application/json; charset=utf-8", ".ico": "image/x-icon"}

# ---------------------------------------------------------------- 화면 표시용 정리 (규칙 아님)
CONDITION_KO = {"poisoned": "중독", "antitoxin": "해독제 효과", "restrained": "포박(Restrained)", "grappled": "붙잡힘",
                "dying": "빈사", "stable": "안정(의식 없음)", "dead": "사망", "in_pit": "구덩이에 빠짐",
                "protection_from_evil_and_good": "보호의 결계(집중)", "incapacitated": "행동 불능",
                "frightened": "겁에 질림", "turned": "퇴치됨", "hidden": "숨음"}
FLAG_KO = {
    "got_rina_doll": "리나의 인형을 받았다",
    "opened_chest": "할빅 서재의 서랍을 열었다",
    "heard_lullaby": "메라의 자장가를 끝까지 들었다",
    "well_entrance_known": "우물 입구를 확인했다",
    "bell_chamber_known": "종실의 존재를 알았다",
    "tracked_rats": "쥐 떼의 흔적을 쫓았다",
    "ooze_noticed": "물속의 점액을 알아챘다",
}
VAR_KO = {
    "quest_accepted": "할빅의 의뢰를 받았다",
    "halvik_lie_noticed": "할빅의 말이 어딘가 어긋난다고 느꼈다",
    "ev_body_marks": "할빅의 손에서 수상한 흔적을 보았다",
    "needle_found": "서랍 자물쇠의 독침을 발견했다",
    "well_recently_opened": "우물 뚜껑이 최근에 열린 흔적을 찾았다",
    "rope_anchored": "갱도에 밧줄과 피톤을 고정했다",
    "water_cut_noticed": "측면 물길이 누군가 뚫은 것임을 알아챘다",
    "rats_driven": "측면 통로의 쥐 떼를 몰아냈다",
    "shrieker_resolved": "100피트 지점의 버섯 무리를 지나왔다",
    "shrieker_alerted": "버섯의 비명이 갱도 아래까지 울려 퍼졌다",
}
# 대화 패널에 보여 줄 화자: 원본 NPC 카드 → 초상화 키
NPC_CARD = {"scn-s1-npc-halvik": "halvik", "scn-s1-npc-mera": "mera", "scn-q4-npc-mera-song": "mera",
            "scn-q1-npc-sera": "sera", "scn-m-npc-smith": "gran", "scn-m-npc-innkeeper": "odan",
            "scn-g-rumors": "villagers"}
NPC_NAME = {"halvik": "할빅", "mera": "메라", "sera": "세라", "gran": "그란", "odan": "오단", "villagers": "마을 사람들"}
# 선택지 → 그 행동에서 나온 'say' 문장의 화자 (화면 배치용)
SPEAKER_BY_CHOICE = [("hh_", "halvik"), ("mk_innkeeper", "odan"), ("mk_rumor_halvik", "odan"), ("mk_smith", "gran"),
                     ("buy:rope", "gran"), ("buy:iron_spikes", "gran"), ("ws_mera", "mera"), ("ws_listen", "mera"),
                     ("sq_sera", "sera"), ("sq_take_doll", "sera"), ("move:halvik_study", "halvik")]


def speaker_for(choice_id, text):
    """'say' 문장을 누가 말했는지 (대화 창 초상화용). 따옴표가 있는 문장만, 선택지 id 접두어로 판단한다."""
    if '"' not in text and "“" not in text:
        return None
    for prefix, who in SPEAKER_BY_CHOICE:
        if choice_id and choice_id.startswith(prefix):
            return who
    return None


class Session:
    """브라우저 한 판 = Engine 하나. mode는 "story"(이야기) 또는 "arena"(전투 시험장).
    lock: 서버가 요청을 여러 스레드로 받으므로, 같은 판에 두 요청이 동시에 들어와도 차례로 처리하게 한다."""

    def __init__(self, engine, narrator):
        self.engine = engine
        self.narrator = narrator
        self.lock = threading.Lock()
        self.mode = "story"
        self.rag_history = []   # 시나리오 RAG 서술의 '최근 기록': (플레이어 입력, 서술) 목록
        self.rag_pending = {}   # rag_id -> (입력, 그때의 상태): 아직 서술을 받아 가지 않은 요청
        self.rag_lock = threading.Lock()   # 서술은 느리므로 엔진용 lock과 따로 둔다


class Game:
    """서버 전체에서 하나. Content(데이터)는 한 번만 읽어 모든 세션이 같이 쓰고, 세션은 sid로 찾는다.
    narrator_factory: 세션마다 서술기를 새로 만드는 함수 (--narrator 옵션에 따라 TemplateNarrator 또는 Ollama)."""

    def __init__(self, narrator_factory, rag_narration=True):
        self.content = Content()
        self.sessions = {}
        self.narrator_factory = narrator_factory
        self.rag_narration = rag_narration   # 시나리오 RAG가 자유 입력에 서술(Ollama)까지 쓸지

    # ------------------------------------------------------------ 메타 정보
    def meta(self):
        """/api/meta. 캐릭터 AC·HP 등은 임시 Engine을 만들어 엔진 계산값을 그대로 쓴다 (서버가 따로 계산하지 않음)."""
        chars = []
        for c in self.content._chars:
            e = Engine(content=self.content, seed=0, char_id=c["id"])
            h = e.hero
            chars.append({
                "id": h.id, "name": h.name, "cls": h.cls, "cls_ko": h.cls_ko, "species": h.species,
                "background": h.background, "hp": h.max_hp, "ac": e.armor_class(h),
                "abilities": [{"id": a, "ko": ABILITY_KO[a], "score": h.score(a), "mod": h.mod(a)} for a in ABILITIES],
                "skills": [SKILL_KO[s] for s in h.skill_profs],
                "weapons": [self.content.rules["weapons"][w]["name"] for w in h.weapons],
                "spells": [self.content.rules["spells"][s]["name"] for s in h.cantrips + h.spells],
                "darkvision": h.darkvision,
            })
        encs = [{"id": k, "name": v["name"], "level": v["level"], "scene": v["scene"],
                 "monsters": [{"kind": g["monster"], "name": self.content.monsters[g["monster"]]["name"], "count": g["count"]}
                              for g in v["monsters"]]}
                for k, v in self.content.encounters.items()]
        return {"characters": chars, "encounters": encs, "save_available": False,
                "scenes": {str(k): {"title": v, "status": self.content.scene_status[k]} for k, v in self.content.scene_titles.items()}}

    # ------------------------------------------------------------ 세션
    def new(self, body):
        """/api/new. 새 Engine(새 게임)을 만들고 sid를 발급한다. combat이 있으면 전투 시험장 모드로 바로 전투 시작."""
        e = Engine(content=self.content, seed=body.get("seed"), char_id=body["char"])
        sess = Session(e, self.narrator_factory())
        events = e.opening
        if body.get("potions"):
            e.s.inventory["potion_healing"] = int(body["potions"])
        if body.get("combat"):  # 전투 시험장: 장면에 아직 연결되지 않은 W6 조우를 바로 시작
            enc = body["combat"]
            if enc not in self.content.encounters:
                raise ValueError(f"없는 조우: {enc}")
            sess.mode = "arena"
            events = e._level_up(e.hero, self.content.encounters[enc]["level"]) + e.start_combat(enc)
        sid = secrets.token_hex(8)
        self.sessions[sid] = sess
        return self.reply(sid, sess, events, None)

    def get(self, sid):
        if sid not in self.sessions:
            raise KeyError("세션이 없습니다. 새 게임을 시작하세요.")
        return self.sessions[sid]

    def choose(self, body):
        """/api/choose. 화면에서 누른 선택지 id를 엔진에 그대로 넘긴다 (지금 고를 수 없는 id면 엔진이 ValueError → 400)."""
        sess = self.get(body["sid"])
        with sess.lock:
            events = sess.engine.choose(body["id"])
            return self.reply(body["sid"], sess, events, body["id"])

    def restart(self, body):
        sess = self.get(body["sid"])
        with sess.lock:
            events = sess.engine.restart_from_checkpoint()
            return self.reply(body["sid"], sess, events, None)

    def free(self, body):
        """[임시] 자유 입력 → 현재 선택지 중 낱말이 가장 많이 겹치는 것을 고른다. 판정은 엔진이 한다.
        덧붙임: 시나리오 RAG(backend/scenario.py)가 지금 상태에서 볼 수 있는 카드를 찾아 free["cards"]로,
        그 카드를 근거로 쓴 서술을 free["narration"]으로 같이 보낸다."""
        sess = self.get(body["sid"])
        with sess.lock:
            cards, rag_id = self.scenario_reply(sess, body.get("text", ""))
            views = sess.engine.available_choices()
            best, score, ranked = match_free_text(body.get("text", ""), views)
            if best is None:
                sugg = [v.label for v in ranked[:3]]
                return dict(self.reply(body["sid"], sess, [], None, narrate=False),
                            free={"matched": None, "suggestions": sugg, "cards": cards, "rag_id": rag_id,
                                  "message": "그 행동은 아직 직접 처리할 수 없습니다. 아래 선택지 중에서 골라 주세요."})
            events = sess.engine.choose(best.id)
            out = self.reply(body["sid"], sess, events, best.id)
            out["free"] = {"matched": best.label, "suggestions": [], "cards": cards, "rag_id": rag_id,
                           "message": f"‘{best.label}’(으)로 처리했습니다."}
            return out

    def scenario_reply(self, sess, text):
        """시나리오 RAG의 빠른 부분: 카드 검색만 한다 (0.1초 안팎). → (카드 dict 목록, rag_id 또는 None).
        서술 생성은 느려서(모델이 몇 초~수십 초) 여기서 하지 않는다. 그 입력과 '지금 상태'를 sess.rag_pending에
        맡겨 두고 rag_id만 돌려주면, 화면이 /api/rag_narrate로 따로 서술을 받아 간다.
        → 서술을 기다리는 동안에도 엔진 요청(선택지 고르기)이 막히지 않는다."""
        if not text.strip():
            return [], None
        state = scenario.state_from_engine(sess.engine)
        try:
            cards = scenario.find_cards(text, state, k=2)
        except Exception as err:       # 임베딩 모델 미설치 등
            print(f"[시나리오 RAG 오류] {err}", flush=True)
            return [], None
        rag_id = None
        if self.rag_narration and cards:
            rag_id = secrets.token_hex(4)
            sess.rag_pending[rag_id] = (text, state)
        return cards, rag_id

    def rag_narrate(self, body):
        """/api/rag_narrate {"sid", "rag_id"} → 시나리오 RAG 서술 하나 (느림). 엔진 락을 잡지 않는다.
        세션별 rag_lock으로 서술끼리는 차례로 처리해 rag_history(최근 기록)가 입력 순서대로 쌓이게 한다.
        실패해도 200으로 error만 돌려줘서, 화면이 '서술 실패'를 표시하고 게임은 계속된다."""
        sess = self.get(body["sid"])
        if body.get("rag_id") not in sess.rag_pending:
            raise KeyError("이미 처리했거나 없는 서술 요청입니다.")
        text, state = sess.rag_pending.pop(body["rag_id"])
        with sess.rag_lock:
            started = time.time()
            try:
                narration, hits, info = scenario.narrate_scene(text, state, sess.rag_history)
            except Exception as err:   # Ollama가 꺼져 있는 경우 등
                print(f"[시나리오 RAG 서술 오류] {err}", flush=True)
                return {"narration": None, "error": str(err)}
            sess.rag_history.append((text[:60], narration[:120]))
            seconds = round(time.time() - started, 1)
            print(f"[시나리오 RAG] 서술 {seconds}초 (모델 {info.get('llm_seconds')}초) | 시도 {info['tries']}번 | 남은 문제 {info['problems'] or '없음'}", flush=True)
            return {"narration": narration, "seconds": seconds, "tries": info["tries"], "problems": info["problems"]}

    # ------------------------------------------------------------ 응답 만들기
    def reply(self, sid, sess, events, choice_id, narrate=True):
        """모든 API 응답의 공통 형식. events = 이번 행동의 결과(화면 기록용), state = 행동 뒤 전체 상태(snapshot).
        AI 서술은 TemplateNarrator가 아닐 때만 만든다."""
        e = sess.engine
        evs = [self.event_json(e, ev, choice_id) for ev in events if ev.kind != "flag"]
        narration = None
        if narrate and events and not isinstance(sess.narrator, TemplateNarrator):
            narration = sess.narrator.narrate(e, events, e.hero.id)
        return {"sid": sid, "mode": sess.mode, "events": evs, "narration": narration, "state": self.snapshot(e)}

    def event_json(self, e, ev, choice_id):
        """Event 하나를 JSON으로. 카드면 카드 종류·라벨을, NPC 문장이면 화자(초상화 키)를 덧붙인다."""
        out = {"kind": ev.kind, "text": ev.text, "data": _plain(ev.data)}
        if ev.kind == "card":
            card = self.content.cards[ev.data["id"]]
            out["card_kind"] = card["kind"]
            out["label"] = card["label"]
            if ev.data["id"] in NPC_CARD:
                who = NPC_CARD[ev.data["id"]]
                out["speaker"], out["speaker_name"] = who, NPC_NAME[who]
        elif ev.kind == "say":
            who = speaker_for(choice_id, ev.text)
            if who:
                out["speaker"], out["speaker_name"] = who, NPC_NAME[who]
        return out

    def snapshot(self, e):
        """화면이 그리는 상태 전체 (상단 장소, 상태창 4개 탭, 전투 패널, 선택지 버튼). web/app.js renderState()가 읽는다.

        숨김 원칙: 단서 탭에는 플레이어에게 이미 보여 준 카드(player_known_cards)만 넣고,
        적은 HP 숫자 대신 wound(멀쩡함/다침/피투성이)만 보낸다. 선택지는 group으로 묶어 화면이 구역별로 나눈다.
        """
        s, h, c = e.s, e.hero, self.content
        clues = []
        for cid in e.player_known_cards(h.id):
            card = c.cards[cid]
            if card["kind"] in ("clue", "rumor", "npc"):
                text = e._view_text(cid)[0]
                clues.append({"id": cid, "kind": card["kind"], "label": _title(text, card["label"]), "text": text,
                              "room": c.room_name(card["room"]) if card["room"] else ""})
        progress = [FLAG_KO.get(f, f) for f in sorted(s.flags)]
        progress += [VAR_KO[k] for k in VAR_KO if s.vars.get(k)]
        combat = None
        if s.combat:
            cb = s.combat
            enemies = []
            for m in cb["enemies"].values():
                md = c.monsters[m["kind"]]
                enemies.append({"id": m["id"], "kind": m["kind"], "name": m["name"], "wound": e.wound_text(m) if not m["out"] else
                                ("쓰러짐" if m["out"] == "dead" else "달아남"), "out": m["out"], "ac": md["ac"], "type": md["type"],
                                "conditions": [CONDITION_KO.get(k, k) for k in m["conditions"]],
                                "bloodied": m["hp"] * 2 <= m["hp_max"]})
            order = [h.name if o == "hero" else cb["enemies"][o]["name"] for o in cb["order"]]
            combat = {"encounter": cb["enc"], "name": c.encounters[cb["enc"]]["name"], "round": cb["round"],
                      "enemies": enemies, "order": order, "turn_index": cb["idx"],
                      "turn": cb["turn"], "dodging": cb["dodging"]}
        choices = []
        for v in e.available_choices():
            group = _group(v.id)
            choices.append({"id": v.id, "key": v.key, "label": v.label, "check": v.check_text, "group": group})
        inv = [{"id": i, "name": c.items[i]["name"], "count": n, "quest": bool(c.items[i].get("quest"))}
               for i, n in s.inventory.items() if n]
        room = c.encounters[s.combat["enc"]]["room"] if s.combat else s.room   # 전투 시험장: 조우 장소 표시
        return {
            "scene": s.scene, "scene_title": c.scene_titles[s.scene], "scene_status": c.scene_status.get(s.scene),
            "room": room, "room_name": c.room_name(room), "minutes": s.minutes,
            "gold": fmt_money(s.gold_cp), "ended": s.ended, "checkpoint": e.checkpoint_label,
            "hero": {
                "id": h.id, "name": h.name, "cls": h.cls, "cls_ko": h.cls_ko, "species": h.species, "level": h.level,
                "hp": h.hp, "max_hp": h.max_hp, "ac": e.armor_class(h),
                "abilities": [{"id": a, "ko": ABILITY_KO[a], "score": h.score(a), "mod": h.mod(a)} for a in ABILITIES],
                "conditions": [CONDITION_KO.get(k, k) for k in h.conditions],
                "hd": f"{h.hd_left}/{h.hd_max} (d{h.hit_die})", "inspiration": h.heroic_inspiration,
                "resources": _resources_ko(h.resources), "down": h.down,
                "death_saves": h.conditions.get("dying") if isinstance(h.conditions.get("dying"), dict) else None,
            },
            "inventory": inv, "clues": clues, "progress": progress, "visited": [c.room_name(r) for r in sorted(s.visited)],
            "visited_ids": sorted(s.visited),   # 미니맵(web/map.js)이 가 본 방을 id로 구분하려고
            "combat": combat, "choices": choices, "pending": (s.pending or {}).get("type"),
        }


def _title(text, fallback):
    """카드 문장의 첫 마디를 제목으로 (예: '할빅 — 에코 타운의 촌장' → '할빅', '소문 — 종소리.' → '소문 — 종소리')."""
    head = re.split(r"[.。]", text or "", maxsplit=1)[0]
    if head.startswith("소문 —"):
        return head[:24]
    head = head.split(" — ")[0]
    return head[:24] if head else fallback


def _resources_ko(r):
    """직업 자원(주문 슬롯·Second Wind 등 남은 횟수)을 상태창용 한국어 줄로."""
    names = {"second_wind": "Second Wind", "action_surge": "Action Surge", "channel_divinity": "Channel Divinity",
             "arcane_recovery": "Arcane Recovery"}
    out = []
    for k, v in r.items():
        if k == "slots":
            out.append(f"주문 슬롯 " + " / ".join(f"{i + 1}레벨 {n}" for i, n in enumerate(v)))
        else:
            out.append(f"{names.get(k, k)} {v}회")
    return out


def _group(cid):
    """선택지 id → 화면 구역 이름 (web/app.js GROUP_ORDER·GROUP_LABEL과 짝). 규칙에는 영향 없음."""
    kind = cid.split(":")[0]
    if kind == "cmb":
        sub = cid.split(":")[1]
        if sub in ("use", "wind") or cid.endswith(":healing_word:self"):
            return "bonus"
        if sub in ("option", "end", "surge"):
            return "combat_other"
        return "combat_action"
    return {"move": "move", "buy": "shop", "use": "item", "rest": "rest", "revisit": "action",
            "inspire": "pending", "hd": "pending", "wake": "pending", "kit": "pending", "aid": "pending"}.get(kind, "action")


def _plain(d):
    """Event.data를 JSON으로 보낼 수 있게. 바꿀 수 없는 값이 섞여 있으면 문자열로 바꾼다."""
    try:
        json.dumps(d)
        return d
    except TypeError:
        return {k: str(v) for k, v in d.items()}


TOKEN = re.compile(r"[가-힣A-Za-z0-9']+")
JOSA = re.compile(r"(에게서|에게|에서|으로|을|를|이|가|은|는|에|로|와|과|의|도|만)$")


MOVE_WORDS = ("간다", "가자", "가다", "가본다", "이동", "향한다", "들어간다", "나간다", "돌아간다")


def _tokens(text):
    """자유 입력 비교용 낱말 집합. 두 글자 이상 낱말만, 끝의 조사는 떼어 낸다."""
    out = set()
    for t in TOKEN.findall(text or ""):
        while len(t) > 2:                      # 조사를 떼어 낸다 (우물가로 → 우물가 → 우물)
            s = JOSA.sub("", t)
            if s == t:
                break
            t = s
        if len(t) >= 2:
            out.add(t)
    return out


def match_free_text(text, views):
    """[임시] 자유 입력 → 현재 선택지 하나. 판정은 엔진이 한다.
    점수: 겹치는 낱말마다 (2 ÷ 그 낱말이 들어 있는 선택지 수), 동사(…다/…고)는 절반, 부분 일치는 다시 절반.
    이동하는 말이 있으면 이동 선택지에 가산. 1위가 1.5점 이상이고 2위보다 0.5점 넘게 높을 때만 처리."""
    want = _tokens(text)
    labels = [(v, _tokens(v.label)) for v in views]
    df = {w: max(1, sum(1 for _, ls in labels if any(w in l or l in w for l in ls))) for w in want}
    moving = any(m in (text or "") for m in MOVE_WORDS)
    scored = []
    for v, ls in labels:
        s = 0.0
        for w in want:
            best = 0.0
            for l in ls:
                if w in l or l in w:
                    weight = 2 / df[w] * (0.5 if w.endswith(("다", "고")) else 1)
                    best = max(best, weight if w == l else weight / 2)
            s += best
        if moving and v.id.startswith("move:") and s > 0:
            s += 1.5
        scored.append((s, v))
    scored.sort(key=lambda x: -x[0])
    ranked = [v for s, v in scored if s > 0] or [v for _, v in scored]
    if not scored or scored[0][0] < 1.5 or (len(scored) > 1 and scored[1][0] > scored[0][0] - 0.5):
        return None, 0, ranked
    return scored[0][1], scored[0][0], ranked


# ---------------------------------------------------------------- HTTP
def make_handler(game):
    """HTTP 요청 처리 클래스를 만든다. URL 경로를 Game의 메서드로 연결하는 일만 하고,
    오류는 KeyError → 404(세션 없음 등), ValueError·RuntimeError → 400(고를 수 없는 선택지 등)으로 돌려준다."""
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, body, ctype="application/json; charset=utf-8"):
            data = body if isinstance(body, bytes) else json.dumps(body, ensure_ascii=False).encode("utf-8")
            try:
                self.send_response(code)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionResetError):
                # 답을 만드는 동안 브라우저(또는 터널)가 연결을 먼저 끊은 경우. 보낼 곳이 없으니 조용히 넘어간다.
                print("[연결 끊김] 응답을 보내기 전에 브라우저가 연결을 닫았습니다.", flush=True)

        def do_GET(self):
            url = urlparse(self.path)
            if url.path == "/api/meta":
                return self._send(200, game.meta())
            if url.path == "/api/state":
                sid = parse_qs(url.query).get("sid", [""])[0]
                try:
                    sess = game.get(sid)
                except KeyError as err:
                    return self._send(404, {"error": str(err)})
                return self._send(200, game.reply(sid, sess, [], None, narrate=False))
            # 정적 파일: web/ 폴더 밖을 가리키는 경로(../ 등)는 404로 막는다
            path = (WEB / url.path.lstrip("/")).resolve() if url.path != "/" else WEB / "index.html"
            if not str(path).startswith(str(WEB.resolve())) or not path.is_file():
                return self._send(404, {"error": "not found"})
            return self._send(200, path.read_bytes(), MIME.get(path.suffix, "application/octet-stream"))

        def do_POST(self):
            url = urlparse(self.path)
            try:
                body = json.loads(self.rfile.read(int(self.headers.get("Content-Length") or 0)) or b"{}")
                route = {"/api/new": game.new, "/api/choose": game.choose, "/api/restart": game.restart,
                         "/api/free": game.free, "/api/rag_narrate": game.rag_narrate}.get(url.path)
                if not route:
                    return self._send(404, {"error": "not found"})
                return self._send(200, route(body))
            except KeyError as err:
                return self._send(404, {"error": str(err)})
            except (ValueError, RuntimeError) as err:
                return self._send(400, {"error": str(err)})

    return Handler


def main(argv=None):
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser()
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--narrator", choices=["template", "ollama"], default="template")
    p.add_argument("--ollama-url", default="http://localhost:11434")
    p.add_argument("--model", default="qwen2.5:7b")
    p.add_argument("--rag-model", default="qwen2.5:14b", help="시나리오 RAG 서술에 쓸 Ollama 모델")
    p.add_argument("--no-rag-narration", action="store_true", help="시나리오 RAG 서술을 끄고 카드 검색만 한다")
    a = p.parse_args(argv)
    scenario.configure(a.ollama_url, a.rag_model)
    factory = (lambda: OllamaNarrator(a.ollama_url, a.model)) if a.narrator == "ollama" else TemplateNarrator
    try:
        scenario.load()   # 카드 읽기 + 임베딩 모델 올리기 (처음 한 번만, 첫 자유 입력이 느려지지 않게 미리)
        print("시나리오 RAG 준비 완료", flush=True)
    except Exception as err:
        print(f"시나리오 RAG를 켜지 못했습니다 (게임은 RAG 없이 계속 실행): {err}", flush=True)
    ThreadingHTTPServer.allow_reuse_address = False   # Windows에서 같은 포트에 서버가 두 개 뜨지 않게 (세션이 섞임)
    try:
        srv = ThreadingHTTPServer((a.host, a.port), make_handler(Game(factory, rag_narration=not a.no_rag_narration)))
    except OSError:
        print(f"포트 {a.port}을(를) 이미 다른 프로그램(이미 켜 둔 게임 서버 등)이 쓰고 있습니다. "
              f"켜져 있는 서버 창을 쓰거나, 끄고 다시 실행하세요. 다른 포트: --port 8765", flush=True)
        return
    print(f"「잠긴 종」 게임 서버: http://{a.host}:{a.port}  (종료: Ctrl+C)", flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
