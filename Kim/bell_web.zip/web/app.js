/* 「잠긴 종」 화면. 판정·피해·상태 계산은 하지 않는다 — 서버(Python 엔진)가 준 결과를 보여 줄 뿐이다. */
/* 흐름: boot() → /api/meta → 메뉴 → startGame() /api/new → render()
 *       → 선택지 클릭·키 입력 choose() /api/choose → render() → … (자유 입력은 /api/free)
 * 서버 응답 r = { sid, mode, events, narration, state } — events는 기록창(log)에, state는 상태창·선택지에 그린다.
 * 소리는 audio.js의 window.Sound를 부른다 (index.html에서 audio.js를 먼저 불러온다). */
"use strict";
const $ = s => document.querySelector(s);
const el = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

// 방 id → 배경 그림 파일 이름 (assets/bg/*.svg). 새 방에 배경을 붙이려면 여기에 추가한다. 없으면 dungeon.
const BG = { village_square: "village_square", halvik_house: "halvik_house", halvik_study: "halvik_study",
  village_market: "village_market", well_side: "well_side", shaft_upper: "shaft_upper", ledge_60: "ledge_60", shaft_lower: "shaft_lower" };
const GROUP_LABEL = { pending: "결정", combat_action: "행동", bonus: "보너스 행동", combat_other: "그 밖", action: "행동",
  item: "소모품", rest: "휴식", shop: "상점", move: "이동" };
// 선택지 구역 순서. 구역 이름(group)은 서버 server/webapp.py의 _group()이 정한다.
const GROUP_ORDER = ["pending", "combat_action", "bonus", "combat_other", "action", "item", "rest", "shop", "move"];

// 화면 전역 상태: sid(서버 세션 id), meta(/api/meta 결과), data(마지막 state), mode(story/arena),
// pick*(선택 화면에서 고른 것), busy(요청 중 중복 클릭 막기). 게임 규칙 상태는 여기 없고 서버에만 있다.
const G = { sid: null, meta: null, data: null, mode: "story", pickChar: null, pickEnc: null, arenaChar: "bran",
  shownScene2: false, busy: false, lastChoiceLabel: null };

// 서버 호출. body가 있으면 POST(JSON), 없으면 GET. 서버가 오류(400·404)를 주면 error 문장으로 예외를 던진다.
async function api(path, body) {
  const r = await fetch(path, body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : {});
  const j = await r.json();
  if (!r.ok) throw new Error(j.error || r.statusText);
  return j;
}

/* ---------------------------------------------------------------- 화면 전환 */
function show(name) {
  document.querySelectorAll(".screen").forEach(s => s.classList.toggle("active", s.id === "screen-" + name));
  if (name === "menu") { setBg("village_square"); Sound.music("town"); }
  if (name === "charselect") renderCharSelect();
  if (name === "arena") { renderArena(); setBg("dungeon"); Sound.music("dungeon"); }
}
document.addEventListener("click", e => {
  const go = e.target.closest("[data-go]");
  if (go) { Sound.sfx("click"); show(go.dataset.go); }
});

// 배경 두 장(#bg-a, #bg-b)을 번갈아 쓰며 서서히 바꾼다 (CSS opacity 전환).
let bgFlip = false, bgName = "";
function setBg(name) {
  if (!name || name === bgName) return;
  bgName = name; bgFlip = !bgFlip;
  const on = bgFlip ? $("#bg-a") : $("#bg-b"), off = bgFlip ? $("#bg-b") : $("#bg-a");
  on.style.backgroundImage = `url(assets/bg/${name}.svg)`;
  on.classList.add("show"); off.classList.remove("show");
}

/* ---------------------------------------------------------------- 캐릭터 선택 */
function charCard(c) {
  const b = el("button", "char-card");
  b.innerHTML = `<img src="assets/portraits/${c.id}.svg" alt="">
    <h3>${esc(c.name)}</h3><div class="cls">${esc(c.cls_ko)} · ${esc(c.species)} · ${esc(c.background)}</div>
    <div class="mini"><span>HP <b>${c.hp}</b></span><span>AC <b>${c.ac}</b></span>${c.darkvision ? `<span>암시야 <b>${c.darkvision}ft</b></span>` : ""}</div>
    <div class="abil">${c.abilities.map(a => `<div>${a.ko}<b>${a.score}</b>${a.mod >= 0 ? "+" : ""}${a.mod}</div>`).join("")}</div>
    <div class="line">기술: ${c.skills.map(esc).join(", ")}</div>
    <div class="line">무기: ${c.weapons.map(esc).join(", ")}${c.spells.length ? `<br>주문: ${c.spells.map(esc).join(", ")}` : ""}</div>`;
  return b;
}
function renderCharSelect() {
  const list = $("#char-list"); list.innerHTML = "";
  G.meta.characters.forEach(c => {
    const b = charCard(c);
    if (G.pickChar === c.id) b.classList.add("selected");
    b.onclick = () => { Sound.sfx("click"); G.pickChar = c.id; renderCharSelect(); $("#btn-start").disabled = false; };
    list.append(b);
  });
}
$("#btn-start").onclick = async () => {
  const seed = $("#seed-input").value;
  await startGame({ char: G.pickChar, seed: seed === "" ? null : Number(seed) });
};

/* ---------------------------------------------------------------- 전투 시험장 */
function renderArena() {
  const list = $("#enc-list"); list.innerHTML = "";
  G.meta.encounters.forEach(enc => {
    const b = el("button", "enc" + (G.pickEnc === enc.id ? " selected" : ""));
    const kind = enc.monsters[0].kind;
    b.innerHTML = `<img src="assets/monsters/${kind}.svg" alt=""><div><div class="t">${esc(enc.name)}</div>
      <div class="s">장면 ${enc.scene} · ${enc.level}레벨 · ${enc.monsters.map(m => `${esc(m.name)}×${m.count}`).join(", ")}</div></div>`;
    b.onclick = () => { Sound.sfx("click"); G.pickEnc = enc.id; renderArena(); };
    list.append(b);
  });
  const cl = $("#arena-chars"); cl.innerHTML = "";
  G.meta.characters.forEach(c => {
    const b = el("button", G.arenaChar === c.id ? "selected" : "", `<img src="assets/portraits/${c.id}.svg" alt="">${esc(c.name)} <small class="muted">${esc(c.cls_ko)}</small>`);
    b.onclick = () => { Sound.sfx("click"); G.arenaChar = c.id; renderArena(); };
    cl.append(b);
  });
  $("#btn-arena-start").disabled = !G.pickEnc;
}
$("#btn-arena-start").onclick = () => startGame({ char: G.arenaChar, combat: G.pickEnc, potions: Number($("#arena-potions").value || 0) });

/* ---------------------------------------------------------------- 게임 시작·진행 */
async function startGame(body) {
  try {
    const r = await api("/api/new", body);
    G.sid = r.sid; G.mode = r.mode; G.shownScene2 = false;
    $("#log").innerHTML = ""; hideDialogue();
    show("game");
    render(r, body.combat ? "전투 시험장 입장" : null);
  } catch (err) { alert(err.message); }
}

async function choose(c) {
  if (G.busy) return;
  G.busy = true; Sound.sfx("click");
  try { render(await api("/api/choose", { sid: G.sid, id: c.id }), c.label); }
  catch (err) { flash(err.message); }
  finally { G.busy = false; }
}

$("#free-form").onsubmit = async e => {
  e.preventDefault();
  const text = $("#free-input").value.trim();
  if (!text || G.busy) return;
  G.busy = true;
  try {
    const r = await api("/api/free", { sid: G.sid, text });
    $("#free-input").value = "";
    const f = r.free;
    if (!f.matched) {
      // 엔진이 처리하지 못한 입력: GM의 서술이 오면 그것이 답이다. 서술이 없을 때(꺼짐·실패)만 "처리할 수 없음"을 보여 준다.
      const entry = el("div", "entry");
      entry.append(el("div", "you", esc(text)));
      $("#log").append(entry); scrollLog();
      renderState(r.state);
      const fallback = () => {
        entry.append(el("div", "ev say", esc(f.message) + (f.suggestions.length ? `<br><span class="muted">비슷한 선택지: ${f.suggestions.map(esc).join(" · ")}</span>` : "")));
        scrollLog();
      };
      showScenarioCards(f, G.sid, entry, fallback);
    } else {
      render(r, `${text}  →  ${f.matched}`);
      showScenarioCards(f, G.sid);
    }
  } catch (err) { flash(err.message); }
  finally { G.busy = false; }
};

// 개발자 보기: 켜면 근거 카드·서술 시간·비슷한 선택지를 보여 준다 (발표·디버깅용). 평소(꺼짐)에는 플레이어가 볼 수 없는 정보다.
try { G.dev = localStorage.getItem("bell_dev") === "1"; } catch (e) { G.dev = false; }
function paintDevButton() { const b = $("#btn-dev"); if (b) b.textContent = "개발자 보기: " + (G.dev ? "켜짐" : "꺼짐"); }
paintDevButton();
if ($("#btn-dev")) $("#btn-dev").onclick = () => {
  G.dev = !G.dev;
  try { localStorage.setItem("bell_dev", G.dev ? "1" : "0"); } catch (e) { /* 저장 못 해도 이번 화면에서는 동작 */ }
  paintDevButton();
};

// 시나리오 RAG가 찾아 준 카드를 기록창에 보여 준다 (서버가 free.cards로 보냄). 연결 확인용 표시.
// 서술은 모델이 몇 초~수십 초 걸리므로 기다리지 않는다: 먼저 카드를 보여 주고, 서술 자리에 "쓰는 중" 표시를 둔 뒤
// /api/rag_narrate를 따로 불러 도착하면 그 자리를 바꾼다. 그동안 선택지·자유 입력은 그대로 쓸 수 있다 (G.busy를 잡지 않음).
// entry: 이미 화면에 있는 기록 묶음(안 주면 새로 만든다). onFail: 서술이 없거나 실패했을 때 대신 보여 줄 것.
// 근거 카드와 서술 시간은 개발자 보기(G.dev)가 켜졌을 때만 보인다.
function showScenarioCards(f, sid, entry = el("div", "entry"), onFail = null) {
  const cards = f.cards;
  const show = () => { if (!entry.isConnected) $("#log").append(entry); scrollLog(); };
  const cardsBox = () => {                      // 개발자 보기에서만: 근거로 쓴 카드
    if (!G.dev || !cards || !cards.length) return;
    entry.append(el("div", "ev say muted", "<b>근거로 쓴 카드</b>"));
    for (const c of cards) {
      const snippet = c.text.length > 70 ? c.text.slice(0, 70) + "…" : c.text;
      entry.append(el("div", "ev say muted", `${esc(c.label)}${c.room ? " · " + esc(c.room) : ""} (유사도 ${c.sim})<br>${esc(snippet)}`));
    }
  };
  if (!f.rag_id) {                              // 서술을 만들지 않는 경우 (RAG 서술 꺼짐 · 볼 수 있는 카드 없음)
    if (onFail) onFail();
    cardsBox(); if (entry.childElementCount) show();
    return;
  }
  const box = el("div", "ev say muted", "");
  const t0 = Date.now();
  const tick = () => { box.innerHTML = `<i>GM이 장면을 쓰는 중… ${Math.floor((Date.now() - t0) / 1000)}초</i>`; };
  tick();
  const timer = setInterval(tick, 1000);
  entry.append(box); show();
  api("/api/rag_narrate", { sid, rag_id: f.rag_id }).then(r => {
    clearInterval(timer);
    if (r.narration) {
      box.className = "ev say";
      box.innerHTML = esc(r.narration) + (G.dev ? `<div class="muted" style="font-size:.8em">${r.seconds}초 · 시도 ${r.tries}번</div>` : "");
      if (onFail) entry.append(el("div", "ev say muted", "<small>게임 상태는 바뀌지 않았습니다. 진행하려면 아래 선택지를 고르세요.</small>"));
    } else {                                    // 서술 실패: 플레이어에게는 "처리할 수 없음"과 선택지를, 원인은 개발자 보기에서만
      box.remove();
      if (onFail) onFail();
      if (!onFail || G.dev) entry.append(el("div", "ev say muted", `<i>서술을 만들지 못했습니다 (${esc(r.error || "알 수 없는 오류")}).</i>`));
    }
    cardsBox(); scrollLog();
  }).catch(err => { clearInterval(timer); box.innerHTML = `<i>서술 요청 실패: ${esc(err.message)}</i>`; if (onFail) onFail(); });
}

function flash(msg) { const e = el("div", "entry"); e.append(el("div", "ev damage", esc(msg))); $("#log").append(e); scrollLog(); }
function scrollLog() { const l = $("#log"); requestAnimationFrame(() => { l.scrollTop = l.scrollHeight; }); }

/* ---------------------------------------------------------------- 결과 그리기 */
// 서버 응답 하나를 화면에 반영: 이벤트를 기록창 한 묶음(entry)으로 추가 → 주사위 창·효과음·대화 창
// → 상태창·선택지 다시 그리기(renderState) → 결과 창 판단(afterTurn). label = 기록창 맨 위에 보일 플레이어 행동.
function render(r, label) {
  const prev = G.data;
  G.data = r.state; G.mode = r.mode;
  const entry = el("div", "entry");
  if (label) entry.append(el("div", "you", esc(label)));
  const checks = [];
  let sfx = [];
  for (const ev of r.events) {
    const node = eventNode(ev);
    if (node) entry.append(node);
    if (ev.kind === "check" && (ev.data.roll || ev.data.total != null)) checks.push(ev);
    if (ev.kind === "damage") { sfx.push("hit"); if (ev.data.target) hitEnemy(ev.data.target); }
    if (ev.kind === "status" && /회복/.test(ev.text)) sfx.push("heal");
    if (ev.kind === "card" && ev.speaker) showDialogue(ev.speaker, ev.speaker_name, ev.text.replace(/^\[[^\]]+\]\s*/, ""));
    if (ev.kind === "say" && ev.speaker) showDialogue(ev.speaker, ev.speaker_name, ev.text);
    if (ev.kind === "move") hideDialogue();
  }
  if (r.narration) entry.append(el("div", "ev narr", esc(r.narration)));
  if (entry.childNodes.length) { $("#log").append(entry); scrollLog(); }
  if (checks.length) showDice(checks[checks.length - 1]);
  else sfx.forEach((s, i) => setTimeout(() => Sound.sfx(s), i * 120));
  renderState(r.state);
  afterTurn(prev, r);
}

// 이벤트 종류(kind)별 기록창 모양. 종류 목록은 game/events.py Event.kind 주석 참고.
function eventNode(ev) {
  const t = esc(ev.text);
  switch (ev.kind) {
    case "move": return el("div", "ev move", t.replace(/^==\s*|\s*==$/g, ""));
    case "scene": return el("div", "ev scene", t.replace(/=+/g, "").trim());
    case "card": {
      const body = t.replace(/^\[[^\]]+\]\s*/, "");
      if (ev.card_kind === "desc") return el("div", "ev desc", body);
      const box = el("div", "ev card-box " + (ev.card_kind || ""));
      const lbl = ev.card_kind === "clue" ? "단서 획득" : ev.card_kind === "rumor" ? "소문" : ev.card_kind === "npc" ? (ev.speaker_name || "인물") : (ev.label || "");
      const owner = (t.match(/^\[[^\]]+\]\s*\(([^)]+)\)/) || [])[1];
      box.innerHTML = `<div class="lbl">${lbl}${owner ? " · " + owner : ""}</div>${body.replace(/^\([^)]+\)\s*/, "")}`;
      return box;
    }
    case "say":
      if (ev.speaker) { const s = el("div", "ev speech"); s.innerHTML = `<span class="who">${esc(ev.speaker_name)}</span>${t}`; return s; }
      return el("div", "ev say", t);
    case "check": {
      const ok = ev.data.success ?? ev.data.hit;
      return el("div", "ev check" + (ok === true ? " ok" : ok === false ? " bad" : ""), "🎲 " + t);
    }
    case "end": return el("div", "ev end", t);
    default: return el("div", "ev " + ev.kind, t);
  }
}

// 주사위 연출. 숫자는 엔진이 굴린 값(ev.data)을 그대로 보여 준다 — 여기서 다시 굴리지 않는다.
function showDice(ev) {
  const d = ev.data, box = $("#dice"), die = box.querySelector(".die");
  const roll = d.roll ?? (d.rolls ? d.rolls[0] : "?");
  const ok = d.success ?? d.hit;
  const res = d.crit ? ["치명타!", "crit"] : ok ? [d.hit !== undefined ? "명중" : "성공", "ok"] : [d.hit !== undefined ? "빗나감" : "실패", "bad"];
  $("#die-num").textContent = roll;
  const target = d.dc != null ? `DC ${d.dc}` : d.ac != null ? `AC ${d.ac}` : "";
  const rolls = d.rolls && d.rolls.length > 1 ? ` <span class="muted">(${d.rolls.join(", ")} 중)</span>` : "";
  const mod = d.mod != null ? d.mod : (typeof roll === "number" && d.total != null ? d.total - roll : null);  // 표시만 (계산은 엔진 결과)
  $("#dice-text").innerHTML = `<div class="res ${res[1]}">${res[0]}</div>d20 ${roll}${rolls}${mod != null ? ` ${mod >= 0 ? "+" : ""}${mod}` : ""} = <b>${d.total}</b> ${target ? "vs " + target : ""}`;
  box.classList.remove("hidden"); die.classList.remove("rolling"); void die.offsetWidth; die.classList.add("rolling");
  Sound.sfx("dice");
  setTimeout(() => Sound.sfx(d.crit ? "crit" : ok ? (d.hit !== undefined ? "hit" : "success") : (d.hit !== undefined ? "miss" : "fail")), 600);
  clearTimeout(showDice.t); showDice.t = setTimeout(() => box.classList.add("hidden"), 2600);
}

function showDialogue(who, name, text) {
  $("#dlg-portrait").src = `assets/portraits/${who}.svg`;
  $("#dlg-name").textContent = name; $("#dlg-text").textContent = text;
  $("#dialogue").classList.remove("hidden");
}
function hideDialogue() { $("#dialogue").classList.add("hidden"); }
$("#dlg-close").onclick = hideDialogue;

function hitEnemy(id) {
  setTimeout(() => { const n = document.querySelector(`.enemy[data-id="${id}"]`); if (n) { n.classList.remove("hit"); void n.offsetWidth; n.classList.add("hit"); } }, 50);
}

/* ---------------------------------------------------------------- 상태 */
// state(서버 Game.snapshot 결과)로 상단 장소·배경·음악, 상태창 탭 4개, 전투 패널, 선택지 버튼을 다시 그린다.
function renderState(s) {
  $("#scene-name").textContent = s.combat ? `전투 · ${s.combat.name}` : `장면 ${s.scene} · ${s.scene_title}`;
  $("#room-name").textContent = s.room_name;
  const h = Math.floor(s.minutes / 60), m = s.minutes % 60;
  $("#clock").textContent = `경과 ${h}시간 ${m}분`;
  $("#checkpoint").textContent = `체크포인트: ${s.checkpoint}`;
  setBg(s.combat ? (s.scene >= 2 && BG[s.room] ? BG[s.room] : "dungeon") : (BG[s.room] || "dungeon"));
  Sound.music(s.combat ? "combat" : s.scene >= 2 ? "dungeon" : "town");

  const hero = s.hero;
  $("#hero-portrait").src = `assets/portraits/${hero.id}.svg`;
  $("#hero-name").textContent = hero.name;
  $("#hero-class").textContent = `${hero.cls_ko} ${hero.level}레벨 · ${hero.species}`;
  $("#hp-fill").style.width = `${Math.max(0, Math.min(100, hero.hp / Math.max(1, hero.max_hp) * 100))}%`;
  $("#hp-text").textContent = `HP ${hero.hp} / ${hero.max_hp}`;
  $("#ac").textContent = hero.ac; $("#hd").textContent = hero.hd.split(" ")[0]; $("#gold").textContent = s.gold;

  const conds = hero.conditions.length ? hero.conditions.map(c => `<span class="chip">${esc(c)}</span>`).join("") : '<span class="muted">없음</span>';
  const ds = hero.death_saves ? `<h4>죽음 구원</h4>성공 ${hero.death_saves.success} / 실패 ${hero.death_saves.fail}` : "";
  $("#tab-stats").innerHTML = `
    <div class="abil">${hero.abilities.map(a => `<div>${a.ko}<b>${a.score}</b>${a.mod >= 0 ? "+" : ""}${a.mod}</div>`).join("")}</div>
    <h4>상태 이상</h4><div class="chips">${conds}${hero.inspiration ? '<span class="chip good">영웅적 영감</span>' : ""}</div>${ds}
    <h4>Hit Point Dice</h4>${esc(hero.hd)}
    <h4>직업 자원</h4>${hero.resources.length ? hero.resources.map(esc).join("<br>") : '<span class="muted">없음</span>'}`;

  $("#tab-items").innerHTML = `<h4>소지금</h4>${esc(s.gold)}<h4>소지품</h4>` + (s.inventory.length ?
    s.inventory.map(i => `<div class="item-row"><span>${esc(i.name)}${i.quest ? ' <span class="q">중요</span>' : ""}</span><span>×${i.count}</span></div>`).join("")
    : '<span class="muted">아직 아무것도 없다.</span>');

  const groups = { clue: "단서", rumor: "소문", npc: "만난 인물" };
  $("#tab-clues").innerHTML = Object.entries(groups).map(([k, name]) => {
    const list = s.clues.filter(c => c.kind === k);
    return `<h4>${name} (${list.length})</h4>` + (list.length ? list.map(c => `<div class="clue"><div class="h"><span>${esc(c.label)}</span><span>${esc(c.room)}</span></div><p>${esc(c.text)}</p></div>`).join("") : '<span class="muted">-</span>');
  }).join("");

  $("#tab-progress").innerHTML = `<h4>현재</h4>장면 ${s.scene} · ${esc(s.scene_title)}${s.scene_status === "skeleton" ? ' <span class="muted">(골격만 구현)</span>' : ""}<br>${esc(s.room_name)}
    <h4>진행 상황</h4>${s.progress.length ? `<ul class="progress-list">${s.progress.map(p => `<li>${esc(p)}</li>`).join("")}</ul>` : '<span class="muted">아직 없음</span>'}
    <h4>가 본 곳 (${s.visited.length})</h4>${s.visited.map(esc).join(" · ")}
    <h4>체크포인트</h4>${esc(s.checkpoint)}`;

  if (typeof renderMap === "function") renderMap(s);     // 미니맵 (web/map.js)
  renderCombat(s.combat);
  renderChoices(s.choices);
}

function renderCombat(cb) {
  const p = $("#combat-panel");
  if (!cb) { p.classList.add("hidden"); return; }
  p.classList.remove("hidden");
  $("#combat-title").textContent = `⚔ ${cb.name}`;
  $("#combat-round").textContent = `${cb.round}라운드`;
  $("#enemy-row").innerHTML = cb.enemies.map(m => `<div class="enemy ${m.out ? "out" : ""}" data-id="${m.id}">
    <img src="assets/monsters/${m.kind}.svg" alt=""><div class="n">${esc(m.name)}</div>
    <div class="w ${m.bloodied && !m.out ? "bloodied" : ""}">${esc(m.wound)} · AC ${m.ac}</div>
    <div class="c">${m.conditions.map(esc).join(", ")}</div></div>`).join("");
  $("#turn-order").innerHTML = "순서: " + cb.order.map((n, i) => i === cb.turn_index ? `<b>${esc(n)}</b>` : esc(n)).join(" → ");
}

function renderChoices(choices) {
  const box = $("#choices"); box.innerHTML = "";
  const byGroup = {};
  choices.forEach(c => (byGroup[c.group] = byGroup[c.group] || []).push(c));
  GROUP_ORDER.forEach(g => {
    if (!byGroup[g]) return;
    box.append(el("div", "choice-group-label", GROUP_LABEL[g]));
    byGroup[g].forEach(c => {
      const b = el("button", "choice " + g);
      b.innerHTML = `<span class="k">${esc(c.key)}</span><span>${esc(c.label)}${c.check ? `<span class="chk">${esc(c.check)}</span>` : ""}</span>`;
      b.onclick = () => choose(c);
      box.append(b);
    });
  });
  $("#free-form").classList.toggle("hidden", !!(G.data && G.data.combat));
}

/* ---------------------------------------------------------------- 결과 창 */
// 행동 뒤 결과 창(모달)을 띄울지 정한다: 게임 오버 / 전투 시험장 결과 / 장면 완료(state.ended가 "sceneN_complete")
// / 골격만 있는 장면 안내 / 장면이 바뀌면 종소리. 판단은 서버가 준 state.ended·scene 값으로만 한다.
function afterTurn(prev, r) {
  const s = r.state;
  if (s.ended === "game_over" && G.mode === "arena") {
    Sound.sfx("gameover");
    return modal("패배", `${s.hero.name}이(가) 쓰러졌다. (전투 시험장 — 이야기 진행에는 영향 없음)`, [
      ["같은 전투 다시", () => startGame({ char: G.arenaChar, combat: G.pickEnc, potions: Number($("#arena-potions").value || 0) }), "primary"],
      ["전투 시험장으로", () => show("arena")], ["메인 메뉴", () => show("menu")]], "gameover");
  }
  if (s.ended === "game_over") {
    Sound.sfx("gameover");
    return modal("게임 오버", `${s.hero.name}의 모험이 여기서 끝났다.\n체크포인트: ${s.checkpoint}`, [
      ["체크포인트에서 다시 시작", async () => { const x = await api("/api/restart", { sid: G.sid }); $("#log").innerHTML = ""; render(x, "다시 시작"); }, "primary"],
      ["메인 메뉴", () => show("menu")]], "gameover");
  }
  const ended = r.events.find(e => e.kind === "combat" && e.data && e.data.outcome);
  if (G.mode === "arena" && ended) {
    const names = { victory: "승리", retreat: "물러남", avoid: "전투 회피", peace: "적대 해제" };
    return modal(names[ended.data.outcome] || "전투 종료", `${ended.data.rounds}라운드 · 남은 HP ${s.hero.hp}/${s.hero.max_hp}`, [
      ["같은 전투 다시", () => startGame({ char: G.arenaChar, combat: G.pickEnc, potions: Number($("#arena-potions").value || 0) }), "primary"],
      ["전투 시험장으로", () => show("arena")], ["메인 메뉴", () => show("menu")]]);
  }
  if (G.mode === "story" && s.ended && s.ended.endsWith("_complete")) {
    Sound.sfx("bell");
    const end = r.events.find(e => e.kind === "end");
    return modal(`장면 ${s.scene} 완료`, (end ? end.text : "") + `\n\n${s.hero.name} · HP ${s.hero.hp}/${s.hero.max_hp} · 소지금 ${s.gold}\n(다음 장면은 아직 구현되지 않았습니다. 진행 상황은 저장되지 않습니다.)`, [
      ["메인 메뉴", () => show("menu"), "primary"]]);
  }
  if (G.mode === "story" && s.scene_status === "skeleton" && G.shownScene2 !== s.scene) {
    G.shownScene2 = s.scene;   // 골격만 있는 장면에 들어왔을 때만 안내
    Sound.sfx("bell");
    modal(`장면 ${s.scene} · ${s.scene_title}`, "이 장면은 아직 방 이동만 구현되어 있습니다.", [
      ["계속 둘러보기", null, "primary"], ["메인 메뉴", () => show("menu")]]);
  } else if (prev && s.scene > prev.scene) {
    Sound.sfx("bell");          // 장면 전환 종소리
  }
}

function modal(title, text, buttons, cls) {
  const m = $("#modal");
  m.className = "modal " + (cls || "");
  $("#modal-title").textContent = title; $("#modal-text").textContent = text;
  const bx = $("#modal-buttons"); bx.innerHTML = "";
  buttons.forEach(([label, fn, kind]) => {
    const b = el("button", "btn " + (kind || ""), esc(label));
    b.onclick = async () => { m.classList.add("hidden"); Sound.sfx("click"); if (fn) await fn(); };
    bx.append(b);
  });
}

/* ---------------------------------------------------------------- 단축키·버튼 */
// 키보드: 목록 왼쪽의 키를 그대로 누른다 (p·u·b·x는 뒤에 숫자를 하나 더 누름)
let keyPrefix = "";
document.addEventListener("keydown", e => {
  if (!$("#screen-game").classList.contains("active") || e.target.tagName === "INPUT" || !$("#modal").classList.contains("hidden")) return;
  if (e.key.length !== 1 || e.ctrlKey || e.metaKey || e.altKey) return;
  const k = e.key.toLowerCase(), list = (G.data && G.data.choices) || [];
  const key = keyPrefix ? keyPrefix + k : k;
  if (!keyPrefix && "pubx".includes(k)) { keyPrefix = k; return; }
  keyPrefix = "";
  const hit = list.find(c => c.key === key);
  if (hit) choose(hit);
});
document.querySelectorAll(".tab").forEach(t => t.onclick = () => {
  document.querySelectorAll(".tab").forEach(x => x.classList.toggle("active", x === t));
  document.querySelectorAll(".tab-body").forEach(x => x.classList.toggle("active", x.id === "tab-" + t.dataset.tab));
});
$("#btn-panel").onclick = () => $("#sheet").classList.toggle("open");
$("#btn-menu").onclick = () => modal("메뉴", "진행 상황은 저장되지 않습니다 (저장 기능 미구현).", [
  ["계속하기", null, "primary"], ["메인 메뉴로", () => show("menu")]]);
function syncSoundButtons() {
  $("#btn-sound").classList.toggle("off", !Sound.enabled);
  $("#btn-sound-menu").textContent = Sound.enabled ? "소리 끄기" : "소리 켜기";
}
function toggleSound() { Sound.enable(!Sound.enabled); syncSoundButtons(); if (Sound.enabled) Sound.sfx("bell"); }
$("#btn-sound").onclick = toggleSound;
$("#btn-sound-menu").onclick = toggleSound;
// 브라우저 정책상 소리는 첫 클릭 뒤에 켤 수 있다
document.addEventListener("pointerdown", function once() { if (Sound.wanted() && !Sound.enabled) { Sound.enable(true); syncSoundButtons(); } document.removeEventListener("pointerdown", once); });

(async function boot() {
  try { G.meta = await api("/api/meta"); }
  catch (err) { document.body.innerHTML = `<p style="padding:24px">서버에 연결할 수 없습니다: ${esc(err.message)}</p>`; return; }
  syncSoundButtons();
  show("menu");
})();
