/* 「잠긴 종」 사운드 — 모두 Web Audio로 실시간 합성한다 (외부 음원 파일 없음, 저작권 문제 없음).
 *  배경: town(마을 밤), dungeon(지하 갱도), combat(전투)
 *  효과음: click, dice, hit, miss, crit, success, fail, heal, gameover, page
 *  모티프: 원본 시나리오의 종 박자 "세 번, 쉬고, 세 번" [원본 scn-v8-rumor-pattern]
 *  밖으로 내보내는 것은 window.Sound 하나: enable(on) · wanted() · music(이름) · sfx(이름) (app.js가 부른다)
 *  소리 켜기 설정은 localStorage "bell-sound"에 저장. 브라우저 정책 때문에 첫 클릭 전에는 소리가 나지 않는다.
 */
(function () {
  let ctx = null, master = null, musicBus = null, sfxBus = null;
  let current = null, currentName = "", enabled = false;

  function init() {
    if (ctx) return;
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    master = ctx.createGain(); master.gain.value = 0.8; master.connect(ctx.destination);
    musicBus = ctx.createGain(); musicBus.gain.value = 0.55; musicBus.connect(master);
    sfxBus = ctx.createGain(); sfxBus.gain.value = 0.7; sfxBus.connect(master);
  }

  function noiseBuffer(sec) {
    const b = ctx.createBuffer(1, ctx.sampleRate * sec, ctx.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return b;
  }

  function env(g, t, a, peak, dec) {
    g.gain.cancelScheduledValues(t);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + a + dec);
  }

  // 종: 비정수배 배음을 겹친 합성 (멀리서 울리는 소리)
  function bell(out, t, freq, vol, damp) {
    [[1, 1], [2.0, .5], [2.76, .35], [5.4, .18], [0.5, .4]].forEach(([r, a]) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = "sine"; o.frequency.value = freq * r;
      o.connect(g); g.connect(out);
      env(g, t, 0.01, vol * a, damp * (r < 1 ? 1.4 : 1 / Math.sqrt(r)));
      o.start(t); o.stop(t + damp * 1.6 + 0.1);
    });
  }

  // 배경음 한 곡(town / dungeon / combat)을 만든다. 돌려주는 start()/stop()으로 서서히 켜고 끈다.
  function makeScene(name) {
    const out = ctx.createGain(); out.gain.value = 0.0001; out.connect(musicBus);
    const nodes = [], timers = [];
    const lp = ctx.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = name === "combat" ? 900 : 500; lp.connect(out);
    const add = n => (nodes.push(n), n);

    // 드론 패드
    const roots = { town: [110, 164.8, 220.5], dungeon: [55, 82.4, 110.2], combat: [73.4, 110, 146.8] }[name];
    roots.forEach((f, i) => {
      const o = add(ctx.createOscillator()), g = ctx.createGain();
      o.type = name === "combat" ? "sawtooth" : "triangle"; o.frequency.value = f; o.detune.value = (i - 1) * 7;
      g.gain.value = name === "combat" ? 0.05 : 0.08; o.connect(g); g.connect(lp); o.start();
      const l = add(ctx.createOscillator()), lg = ctx.createGain();
      l.frequency.value = 0.05 + i * 0.03; lg.gain.value = 0.04; l.connect(lg); lg.connect(g.gain); l.start();
    });
    // 바람 / 동굴 울림
    const n = add(ctx.createBufferSource()); n.buffer = noiseBuffer(4); n.loop = true;
    const bp = ctx.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = name === "dungeon" ? 180 : 420; bp.Q.value = 0.7;
    const ng = ctx.createGain(); ng.gain.value = name === "town" ? 0.06 : 0.09;
    n.connect(bp); bp.connect(ng); ng.connect(out); n.start();
    const wl = add(ctx.createOscillator()), wg = ctx.createGain(); wl.frequency.value = 0.08; wg.gain.value = 0.04; wl.connect(wg); wg.connect(ng.gain); wl.start();

    // 먼 종소리: 세 번, 쉬고, 세 번
    const bellBus = ctx.createGain(); bellBus.gain.value = name === "combat" ? 0.0 : 0.5;
    const blp = ctx.createBiquadFilter(); blp.type = "lowpass"; blp.frequency.value = name === "dungeon" ? 700 : 1200;
    bellBus.connect(blp); blp.connect(out);
    function bellPattern() {
      const t = ctx.currentTime + 0.1, base = name === "dungeon" ? 196 : 233;
      [0, 1.1, 2.2, 4.6, 5.7, 6.8].forEach(dt => bell(bellBus, t + dt, base, 0.12, 3.2));
    }
    if (name !== "combat") { timers.push(setTimeout(bellPattern, 2500)); timers.push(setInterval(bellPattern, 26000)); }

    // 물방울 (던전) — 사용자 피드백: 높은 '뾱' 소리가 거슬림 → 낮고 둥근 소리로, 훨씬 작고 드물게 (W7)
    if (name === "dungeon") {
      const dripLp = ctx.createBiquadFilter(); dripLp.type = "lowpass"; dripLp.frequency.value = 900; dripLp.Q.value = 0.3;
      const dripBus = ctx.createGain(); dripBus.gain.value = 0.35; dripLp.connect(dripBus); dripBus.connect(out);
      timers.push(setInterval(() => {
        if (Math.random() < 0.7) return;           // 평균 10초에 한 번 정도
        const t = ctx.currentTime, o = ctx.createOscillator(), g = ctx.createGain();
        o.type = "sine";
        o.frequency.setValueAtTime(520 + Math.random() * 160, t); o.frequency.exponentialRampToValueAtTime(260, t + 0.25);
        o.connect(g); g.connect(dripLp); env(g, t, 0.02, 0.04, 0.6); o.start(t); o.stop(t + 0.9);
      }, 3000));
    }

    // 북 (전투)
    if (name === "combat") {
      let step = 0;
      timers.push(setInterval(() => {
        const t = ctx.currentTime, accent = step % 4 === 0, s = step++ % 8;
        if ([0, 3, 4, 6].includes(s)) {
          const o = ctx.createOscillator(), g = ctx.createGain();
          o.frequency.setValueAtTime(accent ? 120 : 95, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.25);
          o.connect(g); g.connect(out); env(g, t, 0.005, accent ? 0.5 : 0.3, 0.35); o.start(t); o.stop(t + 0.5);
        }
      }, 300));
    }

    return {
      out, start() { out.gain.setTargetAtTime(1, ctx.currentTime, 1.2); },
      stop() {
        out.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.8);
        timers.forEach(x => { clearTimeout(x); clearInterval(x); });
        setTimeout(() => { nodes.forEach(nd => { try { nd.stop(); } catch (e) { } }); out.disconnect(); }, 3500);
      }
    };
  }

  const SFX = {
    click(t) { tone(t, 880, 0.04, "square", 0.05); },
    page(t) { noise(t, 0.15, 2600, 0.06); },
    dice(t) { for (let i = 0; i < 7; i++) noise(t + i * 0.055 + Math.random() * 0.02, 0.03, 3000 + Math.random() * 2000, 0.18); },
    hit(t) { noise(t, 0.12, 900, 0.35); tone(t, 90, 0.25, "sine", 0.45, 40); },
    crit(t) { SFX.hit(t); tone(t + 0.05, 660, 0.4, "triangle", 0.15); tone(t + 0.12, 990, 0.5, "triangle", 0.12); },
    miss(t) { noise(t, 0.22, 1800, 0.12, true); },
    success(t) { tone(t, 523, 0.25, "triangle", 0.14); tone(t + 0.1, 784, 0.4, "triangle", 0.12); },
    fail(t) { tone(t, 196, 0.45, "sawtooth", 0.08, 150); },
    heal(t) { [784, 988, 1175, 1568].forEach((f, i) => tone(t + i * 0.07, f, 0.5, "sine", 0.07)); },
    gameover(t) { bell(sfxBus, t, 98, 0.35, 5); bell(sfxBus, t + 1.8, 92, 0.3, 5); },
    bell(t) { bell(sfxBus, t, 233, 0.2, 3); },
  };
  function tone(t, f, dur, type, vol, toF) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t); if (toF) o.frequency.exponentialRampToValueAtTime(toF, t + dur);
    o.connect(g); g.connect(sfxBus); env(g, t, 0.005, vol, dur); o.start(t); o.stop(t + dur + 0.05);
  }
  function noise(t, dur, freq, vol, sweep) {
    const s = ctx.createBufferSource(); s.buffer = noiseBuffer(Math.max(dur, 0.05) + 0.05);
    const f = ctx.createBiquadFilter(); f.type = "bandpass"; f.frequency.setValueAtTime(freq, t); f.Q.value = 1.2;
    if (sweep) f.frequency.exponentialRampToValueAtTime(freq / 4, t + dur);
    const g = ctx.createGain(); s.connect(f); f.connect(g); g.connect(sfxBus); env(g, t, 0.003, vol, dur); s.start(t); s.stop(t + dur + 0.05);
  }

  window.Sound = {
    get enabled() { return enabled; },
    enable(on) {
      enabled = on;
      try { localStorage.setItem("bell-sound", on ? "1" : "0"); } catch (e) { }
      if (on) { init(); ctx.resume(); if (currentName) { const n = currentName; currentName = ""; this.music(n); } }
      else if (current) { current.stop(); current = null; }
    },
    wanted() { try { return localStorage.getItem("bell-sound") === "1"; } catch (e) { return false; } },
    music(name) {
      if (name === currentName && current) return;
      currentName = name;
      if (!enabled || !ctx) return;
      if (current) current.stop();
      current = name ? makeScene(name) : null;
      if (current) current.start();
    },
    sfx(name) { if (!enabled || !ctx || !SFX[name]) return; SFX[name](ctx.currentTime + 0.01); },
  };
})();
