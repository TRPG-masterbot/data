/* 「잠긴 종」 미니맵 (장면 1~5). 화면 전용: 서버가 준 현재 방(room)과 가 본 방(visited_ids)만 읽어서 그린다.
 * 방 연결은 시나리오 구조 문서(analysis/04_시나리오/04-0 4-2)와 엔진 데이터(scene1·2.json)를 옮긴 것이다.
 * 안개 규칙: 가 본 방은 이름을 보여 주고, 가 본 방과 바로 이어진 안 가 본 방은 "?"로만 보인다.
 *            조건이 걸린 길(점선)은 양쪽 방을 다 가 본 뒤에만 보인다 (숨은 길이 미리 드러나지 않게). */

// x, y = 장면 지도 안 위치 (viewBox 350 x 240). 장면마다 지도 한 장.
const MAP_SCENES = {
  1: { title: "에코 타운", rooms: {
      village_square:  { name: "우물 광장",     x: 150, y: 120 },
      halvik_house:    { name: "촌장 집",       x: 55,  y: 120 },
      halvik_study:    { name: "촌장의 서재",   x: 55,  y: 40 },
      village_market:  { name: "대장간과 여관", x: 262, y: 120 },
      well_side:       { name: "우물가",       x: 150, y: 190 } },
    edges: [["village_square", "halvik_house"], ["halvik_house", "halvik_study"],
            ["village_square", "village_market"], ["village_square", "well_side"]],
    ext: [{ at: "well_side", dx: 0, dy: 26, label: "↓ 수직 갱도 (장면 2)" }] },
  2: { title: "우물 갱도", rooms: {
      shaft_upper: { name: "갱도 상부 (0~60ft)",   x: 160, y: 50 },
      ledge_60:    { name: "60피트 턱",           x: 160, y: 120 },
      shaft_lower: { name: "갱도 하부 (60~150ft)", x: 160, y: 190 } },
    edges: [["shaft_upper", "ledge_60", "rope"], ["ledge_60", "shaft_lower", "rope"]],
    ext: [{ at: "shaft_upper", dx: 0, dy: -26, label: "↑ 우물가 (장면 1)" },
          { at: "shaft_lower", dx: 0, dy: 26, label: "↓ 회랑 입구 (장면 3)", dotted: true }] },
  3: { title: "수몰 회랑", rooms: {
      cloister_entry:   { name: "회랑 입구",       x: 45,  y: 100 },
      cloister_mid:     { name: "회랑 중간",       x: 130, y: 100 },
      infirmary:        { name: "약품실",         x: 130, y: 30 },
      infirmary_inner:  { name: "약품실 안쪽",     x: 220, y: 30 },
      quarry_passage:   { name: "보급 통로",       x: 305, y: 30 },
      cloister_bodies:  { name: "가라앉은 시신",   x: 130, y: 175 },
      monk_cells:       { name: "수도사 숙소",     x: 45,  y: 175 },
      scriptorium_door: { name: "필사실 문 앞",    x: 215, y: 175 } },
    edges: [["cloister_entry", "cloister_mid"], ["cloister_mid", "cloister_bodies"],
            ["cloister_mid", "infirmary", "hidden"], ["infirmary", "infirmary_inner"],
            ["infirmary_inner", "quarry_passage", "hidden"], ["cloister_bodies", "monk_cells"],
            ["cloister_bodies", "scriptorium_door"]],
    ext: [{ at: "cloister_entry", dx: 0, dy: -30, label: "↑ 갱도 (장면 2)" },
          { at: "scriptorium_door", dx: 0, dy: 26, label: "↓ 필사실 홀 (장면 4)", dotted: true }] },
  4: { title: "필사실", rooms: {
      scriptorium_hall:    { name: "필사실 홀",      x: 160, y: 120 },
      scriptorium_desks:   { name: "책상 구역",      x: 55,  y: 50 },
      armor_corner:        { name: "갑옷 구석",      x: 265, y: 50 },
      scriptorium_shelves: { name: "필사실 서가",    x: 55,  y: 190 },
      stairs_down:         { name: "종실로 가는 계단", x: 265, y: 190 } },
    edges: [["scriptorium_hall", "scriptorium_desks"], ["scriptorium_hall", "armor_corner"],
            ["scriptorium_hall", "scriptorium_shelves"], ["scriptorium_hall", "stairs_down", "hidden"]],
    ext: [{ at: "scriptorium_hall", dx: 0, dy: -50, label: "↑ 필사실 문 앞 (장면 3)" },
          { at: "stairs_down", dx: 0, dy: 26, label: "↓ 종실 (장면 5)" }] },
  5: { title: "종실", rooms: {
      bell_chamber:   { name: "종실",              x: 130, y: 110 },
      sluice_works:   { name: "수문 구역",         x: 45,  y: 110 },
      bell_underside: { name: "종 아래",           x: 215, y: 110 },
      bell_tongue:    { name: "종의 혀 아래",      x: 215, y: 190 } },
    edges: [["bell_chamber", "sluice_works"], ["bell_chamber", "bell_underside"], ["bell_underside", "bell_tongue"]],
    ext: [{ at: "bell_chamber", dx: 0, dy: -50, label: "↑ 계단 (장면 4)" },
          { at: "bell_chamber", dx: 0, dy: 50, label: "↓ 사슬 계단 (장면 6)" }] },
};
const MAP_LAST_SCENE = 5;
const MAP_W = 350, MAP_H = 240, NODE_W = 78, NODE_H = 26;
const MAP_SVG_NS = "http://www.w3.org/2000/svg";
let mapViewScene = null;     // 사용자가 직접 고른 장면 (null이면 현재 장면을 따라간다)
let mapLastState = null;

function mapEsc(t) { return String(t).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }

// 한 장면의 지도를 SVG 문자열로 만든다.
function mapSvg(sceneNo, current, visited) {
  const sc = MAP_SCENES[sceneNo];
  const seen = new Set(visited);
  const solidNeighbor = new Set();                       // 가 본 방과 실선으로 이어진 방 (안 가 봤어도 "?"로 보임)
  for (const [a, b, kind] of sc.edges) {
    if (kind) continue;
    if (seen.has(a)) solidNeighbor.add(b);
    if (seen.has(b)) solidNeighbor.add(a);
  }
  const shown = id => seen.has(id) || solidNeighbor.has(id);
  let svg = `<svg class="minimap-svg" viewBox="0 0 ${MAP_W} ${MAP_H}" role="img" aria-label="장면 ${sceneNo} 지도">`;

  for (const [a, b, kind] of sc.edges) {                 // 길
    const A = sc.rooms[a], B = sc.rooms[b];
    const visible = kind ? (seen.has(a) && seen.has(b)) : (shown(a) && shown(b));
    if (!visible) continue;
    const dotted = kind ? ' stroke-dasharray="4 4"' : "";
    svg += `<line x1="${A.x}" y1="${A.y}" x2="${B.x}" y2="${B.y}" class="m-edge"${dotted}/>`;
  }
  for (const ex of sc.ext || []) {                       // 다른 장면으로 가는 길 (그 방을 가 봐야 보임)
    const R = sc.rooms[ex.at];
    if (!seen.has(ex.at)) continue;
    const x2 = R.x + ex.dx, y2 = R.y + ex.dy;
    const dotted = ex.dotted ? ' stroke-dasharray="4 4"' : "";
    const anchor = ex.dx < -10 ? "end" : ex.dx > 10 ? "start" : "middle";
    const ty = ex.dy > 0 ? y2 + 11 : y2 - 5;
    svg += `<line x1="${R.x}" y1="${R.y}" x2="${x2}" y2="${y2}" class="m-edge m-ext"${dotted}/>`
         + `<text x="${x2}" y="${ty}" text-anchor="${anchor}" class="m-ext-label">${mapEsc(ex.label)}</text>`;
  }
  for (const [id, r] of Object.entries(sc.rooms)) {      // 방
    if (!shown(id)) continue;
    const isCur = id === current, isSeen = seen.has(id);
    const cls = isCur ? "m-node m-current" : isSeen ? "m-node m-seen" : "m-node m-unknown";
    svg += `<g class="${cls}"><rect x="${r.x - NODE_W / 2}" y="${r.y - NODE_H / 2}" width="${NODE_W}" height="${NODE_H}" rx="6"/>`
         + `<text x="${r.x}" y="${r.y + 4}" text-anchor="middle">${isSeen ? mapEsc(r.name) : "?"}</text>`;
    if (isCur) svg += `<circle cx="${r.x + NODE_W / 2 - 6}" cy="${r.y - NODE_H / 2 + 6}" r="4" class="m-here"/>`;
    svg += `</g>`;
  }
  return svg + `</svg>`;
}

function renderMap(s) {
  mapLastState = s;
  const box = document.querySelector("#tab-map");
  if (!box) return;
  const here = s.room;
  const roomScene = Object.keys(MAP_SCENES).find(k => MAP_SCENES[k].rooms[here]);   // 지금 있는 방이 속한 장면
  const curScene = roomScene ? Number(roomScene) : Math.min(s.scene, MAP_LAST_SCENE);
  const viewScene = mapViewScene && mapViewScene <= curScene ? mapViewScene : curScene;
  const visited = s.visited_ids || [];

  let tabs = "";
  for (let n = 1; n <= Math.min(curScene, MAP_LAST_SCENE); n++) {
    tabs += `<button class="map-scene${n === viewScene ? " on" : ""}" data-scene="${n}">장면 ${n}</button>`;
  }
  const legend = `<div class="map-legend"><span><i class="lg here"></i>현재</span><span><i class="lg seen"></i>가 본 곳</span><span><i class="lg unk"></i>미확인</span><span><i class="lg dot"></i>조건이 필요한 길</span></div>`;
  box.innerHTML = `<div class="map-scenes">${tabs}</div><div class="map-title">${mapEsc(MAP_SCENES[viewScene].title)}</div>`
    + mapSvg(viewScene, here, visited) + legend;
  box.querySelectorAll(".map-scene").forEach(b => b.onclick = () => { mapViewScene = Number(b.dataset.scene); renderMap(mapLastState); });
}
